
# Gemini Image Demo App

A Streamlit-based web application that allows users to upload an image and optionally provide a prompt to get a descriptive or analytical response from Google's Gemini 1.5 Flash model.

---

## 🧠 Overview

This app uses Google's multimodal capabilities to understand and respond to image inputs with or without textual prompts. Built using `streamlit`, `PIL`, and `google-generativeai`.

---

## 📦 Requirements

- Python 3.7 or higher  
- Google API Key (from [Google AI Studio](https://makersuite.google.com/app))  
- Required Python packages:
  - streamlit
  - python-dotenv
  - google-generativeai
  - Pillow (PIL)

---

## 🛠️ Installation & Setup

### 1. Clone the Repository

```bash
git clone https://github.com/your-username/gemini-image-app.git
cd gemini-image-app
```

### 2. Create a Virtual Environment

```bash
python -m venv venv
```

### 3. Activate the Virtual Environment

- On **Windows**:
  ```bash
  venv\Scripts\activate
  ```
- On **macOS/Linux**:
  ```bash
  source venv/bin/activate
  ```

### 4. Create `requirements.txt`

```txt
streamlit
python-dotenv
google-generativeai
Pillow
```

### 5. Install Dependencies

```bash
pip install -r requirements.txt
```

### 6. Set Up Environment Variables

Create a `.env` file in the root directory and add your Google API key:

```env
GOOGLE_API_KEY=your_api_key_here
```

---

## 🧪 Example Usage

- Upload an image of an object, scene, or diagram.
- Optionally enter a prompt such as:  
  `"What is happening in this image?"`
- Click **Tell me about the image**.
- Receive an AI-generated response based on the image and prompt.

---

## 🖥️ App Code

Create a file named `app.py` and paste the following code:

```python
from PIL import Image
from io import BytesIO
from dotenv import load_dotenv
load_dotenv()

import streamlit as st
import os
import google.generativeai as genai

genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

model = genai.GenerativeModel("gemini-1.5-flash-latest")

def get_gemini_response(input, image):
    if input == "":
        response = model.generate_content([image])
    else:
        response = model.generate_content([input, image])
    return response.text

st.set_page_config(page_title="Gemini Image Demo")
st.header("Gemini Application")

input = st.text_input("Input Prompt: ", key="input")

uploaded_file = st.file_uploader("Choose an image...", type=['jpg', 'png', 'jpeg'])
image = ""
if uploaded_file is not None:
    image = Image.open(uploaded_file)
    st.image(image, caption="Uploaded Image.", use_container_width=True)

submit = st.button("Tell me about the image")

if submit:
    response = get_gemini_response(input, image)
    st.subheader("The response is ")
    st.write(response)
```

---

## 🚀 Run the Application

```bash
streamlit run app.py
```

---

## 📄 License

This project is licensed under the MIT License.

---

## 🙌 Acknowledgments

- [Google Generative AI Python SDK](https://pypi.org/project/google-generativeai/)
- [Streamlit](https://streamlit.io/)
- [Pillow for image processing](https://pypi.org/project/Pillow/)
